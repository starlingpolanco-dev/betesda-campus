BETESDA CAMPUS — BETA PARA PRESENTACIÓN AL PASTOR
Iglesia Estanque de Betesda · Escuela de Discipulado

QUÉ INCLUYE ESTA BETA
- Portada institucional con el logo de la iglesia.
- Acceso rápido a 3 perfiles: Estudiante, Profesor y Administrador.
- Panel del estudiante con materias, tareas, clases, calendario y calificaciones.
- Panel del profesor con materias, creación de asignaciones y seguimiento de estudiantes.
- Panel administrativo con usuarios, materias, anuncios y reportes.
- Vista interna de una materia con módulos, lecciones, materiales y progreso.
- Diseño adaptable para celular, tablet y computadora.

CUENTAS DE DEMOSTRACIÓN
Estudiante: estudiante@betesda.do / 123456
Profesor: profesor@betesda.do / 123456
Administrador: admin@betesda.do / 123456

IMPORTANTE
Esta es una versión BETA visual y funcional para demostración. Los datos no están conectados todavía a una base de datos en Internet. Los botones simulan el flujo final.

CÓMO ABRIR EN LA COMPUTADORA
1. Descomprime el archivo ZIP.
2. Abre la carpeta betesda-campus-beta-pastor.
3. Haz doble clic en index.html.

CÓMO PUBLICAR GRATIS PARA ABRIR EN EL CELULAR
1. Crea una cuenta en Netlify.
2. Usa la opción de despliegue manual.
3. Arrastra la carpeta completa betesda-campus-beta-pastor.
4. Netlify generará un enlace público que podrás abrir y compartir desde cualquier celular.

SIGUIENTE FASE DESPUÉS DE APROBAR LA BETA
- Base de datos real y autenticación.
- Subida de tareas y materiales.
- Google Meet o Zoom.
- Notificaciones.
- Certificados y reportes.
